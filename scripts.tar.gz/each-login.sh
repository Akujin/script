sudo su
mkdir -p /mnt/xvdb1
mount /dev/xvdb1 /mnt/xvdb1
cd /mnt/xvdb1
